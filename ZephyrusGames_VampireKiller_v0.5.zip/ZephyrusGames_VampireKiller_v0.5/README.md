# Vampire-Killer
Castlevania


Github page :

https://github.com/M4xp0w3rg4m3s/Vampire-Killer

Youtube Video of the features :

https://www.youtube.com/watch?v=6NMuUqSo27c

-----Team Members-----

Max Mateo :

https://github.com/M4xp0w3rg4m3s

Guillem Martinez :

https://github.com/GuillemDev

-----Game Description-----

In this game you play Simon Belmont,
a descendant of a legendary clan of 
vampire killers and the current bearer 
of the holy whip "Vampire Killer", 
who will have to advance through seven levels 
(divided in 18 stages) full of monsters and
objects inside Dracula's Castle in Transylvania.
After clearing puzzles to unlock the path and
defeating monstuous bosses he will have a 
fierce battle against Dracula himself to 
vanquish him and put to an end his reign 
of terror.

-----Controls-----

Upwards Arrow - Jump.
Downwards Arrow - Crouch.
Rightwards Arrow - Move to the right.
Leftwards Arrow - Move to the left.
Space - Whip Attack.
Z - Throw.
C - Set weapon to Chain.
1 - Go to Level 1.
2 - Go to Level 2.
3 - Go to Level 3.
4 - Go to Level 4.
F1 - Activate / Deactivate God Mode.
F2 - Activate / Deactivate Debug Mode.
F3 - Instant Win.
F4 - Instant Death.

-----Features-----

- Intro Screen
- Intro Music
- Level 1
- Level 1 Music
- Movement in X axis
- Collisions
- Jump
- Crouch
- Whip Attack
- Whip SFX
- Chain Attack
- Item Chain
- Enemy Zombie
- Enemy Panther
- Throwing
- Dying
- Winning
- Game over Screen
- Win Screen
- Change Level by crossing the screen
- Debug Mode
- God Mode
- Level 2
- Level 3
- Level 4
- Animated Tiles

